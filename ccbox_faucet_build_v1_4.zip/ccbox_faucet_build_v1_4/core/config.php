<?
define('HOST', 'sitename'); 							//type the domain name without protocol e.g. sitename.com
define('SERVPATH','/path/to/folder/sitename'); 			//specify the path to the root folder of your site
define('DATAPATH','/path/to/folder/sitename/data');  	//replace the path to the data folder

define('FAUCET_SECTION', 'faucets');					

define('COOKIE_EXP', '30');
define('COOKIE_NAME', '__CCC');
define('COOKIE_REF_NAME', '__CCR');
define('COOKIE_HTTPS', false);
define('COOKIE_HTTP_ONLY', false);

define('MAILHOST', '');
define('MAILPORT', 465);
define('MAILBOXNAME', '');
define('MAILDOMAIN', '');
define('MAILPASS', '');
define('MAILSSL', true);

define('TEMPLATE', 'base');

define("AUTOWITHDRAW",true);

define('DBHOST', 'localhost');	            //localhost or server ip 
define('DBNAME', '');		    			//your MYSQL Database name
define('DBUSER', '');						//your MYSQL Database user name
define('DBPASS', '');						//your MYSQL Database user password
define('PREFIX', 'f');
?>