<?
$functions = new functions();
$opt = array(
PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
);
try{ $dbh = new PDO(functions::replace("mysql:host=%h;dbname=%b;charset=UTF8",array("%h"=>DBHOST,"%b"=>DBNAME)), DBUSER, DBPASS, $opt);  }
catch (Exception $e) { header ("location: /install"); }
$____url	=	parse_url(preg_replace('|([/]+)|s', '/', $_SERVER['REQUEST_URI']));
$current	=	explode("/", $____url['path']);
$_sect_arr  =   array(0,1);
if($_GET&&$_GET['ref']&&!functions::auth()){ $_GET['ref'] = preg_replace('~[^0-9]+~','',$_GET['ref']); setcookie(COOKIE_REF_NAME, $_GET['ref'], time()+3600, "/", HOST); }
//////////
//
//
try{ $stmt = $dbh->query(functions::replace("SELECT `n_id`, `n_hash`, `n_okey`, `n_skey`, `n_sitename`, `n_daily`, `n_daily_o`, `n_hp`, `n_iphub`, `n_iphub_key`, `n_aab`, `n_capt`, `n_capt_okey`, `n_capt_skey`, `n_connect`, `n_zones`, `n_zones_perc`, `n_adv_faucet`, `n_status` FROM `%p_settings` LIMIT 1; ",array("%p"=>PREFIX)))->fetchAll(PDO::FETCH_ASSOC); }
catch (Exception $e) { header ("location: /install"); }
foreach ($stmt as $row) {
	$__FAUCET_DATA = $row;}
if(!$__FAUCET_DATA || $__FAUCET_DATA['n_status'] == 1) $__MAINTENANCE = true;
//////////
//
//
if(!$__FAUCET_DATA['n_hash']||!$__FAUCET_DATA['n_okey']||!$__FAUCET_DATA['n_skey']){
if($current[1]!="install"){
header("location: /install");	
}
}

$sql = functions::replace("SELECT `c_coin`, `c_name`, `c_alias`, `c_timer`, `c_min_pay`, `c_max_pay`, `c_hp`, `c_redirect`, `c_redirect_url`, `c_redirect_backward_url`, `c_deposit`,  `c_withdraw`, `c_min_withdrawal`, `c_fee_withdrawal`,  `c_order`, `c_faucet` FROM `%p_coins` ORDER by c_order ASC",array("%p"=>PREFIX));
$stmt = $dbh->prepare($sql);
$stmt->execute();
$count = $stmt->rowCount();
if($count>0) { 
foreach ($stmt as $row) {
$__COINS_DATA[$row['c_coin']] = $row;
}
} else $__MAINTENANCE = true;
//////////
//
//
if($_ucookie = functions::auth()) {
$sql = functions::replace("SELECT `u_id`, `u_hash`, `u_ip`, `u_session`, `u_name`, `u_email`, `u_password`, `u_reg_datetime`, `u_last_online`, `u_ref_id`, `u_settings`, `u_status` FROM `%p_users` WHERE `u_hash` = :u",array("%p"=>PREFIX));
$stmt = $dbh->prepare($sql);
$stmt->execute(array("u" => $_ucookie['uh']));
$count = $stmt->rowCount();
if($count>0) { 	
foreach ($stmt as $row) {
if($row['u_status']==2) $_sect_arr = array(0,1,2); 
$__USER_DATA = $row;
$__USER_SETTINGS = json_decode($row['u_settings'], true);
}
} else $__MAINTENANCE = true;
}


 //////////
//
// 
$stmt = $dbh->query(functions::replace("SELECT `s_id`, `s_alias`, `s_name`, `s_title`, `s_desc`, `s_settings`, `s_parent`, `s_order`, `s_status` FROM `%p_sections`  WHERE `s_status` IN ('%s')  ORDER BY `s_order` ASC",array("%p"=>PREFIX, "%s" => implode("', '",$_sect_arr))))->fetchAll(PDO::FETCH_ASSOC); 
$c = array();
foreach ($stmt as $key => $row){
$__SECTION_DATA[$row['s_alias']] = $row;
if($row['s_status']!=0) { 
$c['parent'][$row['s_id']] = $row;
$c[$row['s_parent']][$row['s_id']] = $row; }
if($row['s_settings']) $__SECTION_SETTINGS[$row['s_alias']] = json_decode($row['s_settings'], true); 
}
//////////
//
//
$__USER_DATA['zone'] = null;
if($__FAUCET_DATA['n_zones']){
$dbip = new ipzone($dbh);
$inf = $dbip->lookup(functions::getip());
$__USER_DATA['zone'] = $inf->country;
}

?>