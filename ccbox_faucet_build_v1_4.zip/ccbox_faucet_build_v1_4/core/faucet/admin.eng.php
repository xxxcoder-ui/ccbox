<?
//////////
//
// 
if($__USER_DATA['u_status']==2){

$__cookie = functions::auth();
$e = $__cookie['ul'];
$p = $__cookie['up'];
$captblock = null;

if($__FAUCET_DATA['n_capt']==1&&$__FAUCET_DATA['n_capt_okey']&&$__FAUCET_DATA['n_capt_skey'])
{
if(file_exists($_SERVER["DOCUMENT_ROOT"]."/core/recaptchalib.php")) require_once($_SERVER["DOCUMENT_ROOT"]."/core/recaptchalib.php"); else exit("core/recaptchalib.php not found");
$response = null;
$reCaptcha = new ReCaptcha($__FAUCET_DATA['n_capt_skey']);
$captblock = '<br/><div class="g-recaptcha" data-theme="dark" data-sitekey="'.$__FAUCET_DATA['n_capt_okey'].'"></div>';
}	

if($_POST['e']&&$_POST['p']){
	
if($__FAUCET_DATA['n_capt']==1) {
$response = $reCaptcha->verifyResponse($_SERVER["REMOTE_ADDR"],$_POST["g-recaptcha-response"]);
if(!$response->success) $__captccheck['block']=1; }	

if(!$__captccheck['block']){
if($_POST['e']) $e = strip_tags(trim($_POST['e']));
if($_POST['p']) $p = strip_tags(trim(md5(md5($_POST['p']))));
}
}

$engine = array(
"%captcha" => $captblock
);	

if($e && $p && functions::auth($dbh,$e,$p)) {
$hide = null;
if($__FAUCET_DATA['n_connect']==1 && $__COINS_DATA){
//////////
//
// 
if($__FAUCET_DATA['n_daily']>0){	
if(file_exists(DATAPATH.'/market.txt')){$__cryptoapi = file_get_contents(DATAPATH.'/market.txt');} 
$___carr=json_decode($__cryptoapi, true);
if($___carr){
foreach ($___carr['data'] as $k => $v) {  
$__cac[strtolower($v['symbol'])]['price_usd'] = $v['quote']['USD']['price'];
}
$stmt = $dbh->query(functions::replace("SELECT `th_type`, `th_coin`, `th_amount`, `th_datetime` FROM `%p_trs_history` WHERE `th_type` = '0' AND UNIX_TIMESTAMP(CURRENT_DATE()) < th_datetime;",array("%p"=>PREFIX)))->fetchAll(PDO::FETCH_ASSOC); 
foreach ($stmt as $row) {
if($__cac[$row['th_coin']]['price_usd']){	
$___t = $___t + functions::satoshi($row['th_amount'])*$__cac[$row['th_amount']]['price_usd'];
$___a = functions::satoshi($row['th_amount']);
$___i = $___a*$__cac[$row['th_coin']]['price_usd'];		
if(strstr($___i,"E-")) $___i=sprintf('%.8F',$___i);
$___t=$___t+$___i;} 	
if($___t) { $__dp = ( $___t * 100 ) / $__FAUCET_DATA['n_daily']; $___dpt = 100 - $__dp; if($___dpt<0) $___dpt = 0 ; } else { $___dpt=100; }	
if($___t>$__FAUCET_DATA['n_daily']&&$__FAUCET_DATA['n_daily_o']==1) $__dailycheck['block'] = 1;
if($___t>$__FAUCET_DATA['n_daily']&&$__FAUCET_DATA['n_daily_o']==0) { $__COINS_DATA[end($current)]['c_hp'] = 1; $__FAUCET_DATA['n_hp'] = 1; }
$daily_message = '<small><i class="fa fa-info-circle"></i> Sent today &asymp; '.number_format($___t,8).' USD</small>';
}}} else { $daily_message = null; $__FAUCET_DATA['n_daily'] = null; }
//////////
//
//			
foreach ( $__COINS_DATA as  $v ) {
	$active[0]=false; $redirect[0]=false;
	$active[1]=false; $redirect[1]=false;
	$coins_list[] = strtoupper($v['c_coin']);
	if($v['c_faucet']==0) { $disabled=" disabled "; $off_active=" off"; $active[0]=" selected";}  else  { $disabled=null; $off_active=null; $active[1]=" selected"; }
	if($v['c_redirect']==0) { $disabled_redirect_url = "disabled"; $off_redirect_url=" off"; $redirect[0]=" selected";}  else  { $disabled_redirect_url = null; $off_redirect_url=null; $redirect[1]=" selected";}
	if($v['c_hp']==0) $off_hp = " off"; else $off_hp = null;
	
	if(!$v['c_min_pay']) $v['c_min_pay'] = 10;
	$coins['html'].='<br/><div class="row data">
							<div class="col-sm-1">
							 <label><span class="hide-1200">'.strtoupper($v['c_coin']).' </span>Timer</label>
								<input name="coins['.$v['c_coin'].'][c_timer]" class="'.$v['c_coin'].'-settings ctmr form-control" '.$disabled.' type="number" min="1" max="1440" step="1" placeholder="Set timer" value="'.$v['c_timer'].'" required>
							</div>
							<div class="col-sm-2">
							 <label><span class="hide-1200">'.strtoupper($v['c_coin']).' </span>Lower Threshold</label>
								<input name="coins['.$v['c_coin'].'][c_min_pay]"  class="'.$v['c_coin'].'-settings form-control lt" '.$disabled.'  type="number" min="0.00000100" max="1000" step="0.00000010" placeholder="Type '.$v['c_name'].' Lower Threshold" value="'.$functions::satoshi($v['c_min_pay']).'" required>
							</div>							
							<div class="col-sm-1">
							 <label><span class="hide-1200">'.strtoupper($v['c_coin']).' </span>HPP</label>
								<input name="coins['.$v['c_coin'].'][c_hp]"  class="'.$v['c_coin'].'-settings chpp form-control'.$off_hp.'" '.$disabled.'  type="number" min="0" max="100" step="1" placeholder="Type '.$v['c_name'].' High Payout Probability (%)" value="'.$v['c_hp'].'" required>
							</div>
							<div class="col-sm-3">
							 <label>'.strtoupper($v['c_coin']).' Redirect URL</label>
								<input name="coins['.$v['c_coin'].'][c_redirect_url]"  class="'.$v['c_coin'].'-settings '.$v['c_coin'].'-redirect-url form-control" '.$disabled_redirect_url.$disabled.'  type="text" placeholder="Type redirect URL" value="'.$v['c_redirect_url'].'" required>
							</div>
							<div class="col-sm-3">
							 <label>'.strtoupper($v['c_coin']).' Backward URL</label>
								<input name="coins['.$v['c_coin'].'][c_redirect_backward_url]"  class="'.$v['c_coin'].'-settings '.$v['c_coin'].'-redirect-url form-control" '.$disabled_redirect_url.$disabled.'  type="text" placeholder="Type backward URL" value="'.$v['c_redirect_backward_url'].'" required>
							</div>
							<div class="col-sm-1">
							 <label>Redirect</label>
							<select name="coins['.$v['c_coin'].'][c_redirect]"  data-coin="'.$v['c_coin'].'" '.$disabled.' class="'.$v['c_coin'].'-settings '.$v['c_coin'].'-redirect redirect form-control'.$off_redirect_url.'" required>
                              <option value="0" '.$redirect[0].'>off</option>
                              <option value="1" '.$redirect[1].'>on</option>
                              </select>
							</div>
							<div class="col-sm-1">
							 <label>Active</label>	
                              <select name="coins['.$v['c_coin'].'][c_faucet]"  data-coin="'.$v['c_coin'].'" class="active form-control'.$off_active.'" required>
                              <option value="0" '.$active[0].'>off</option>
                              <option value="1" '.$active[1].'>on</option>
                              </select>
							</div>
						</div>';
	
}
if(!$__FAUCET_DATA['n_iphub_key']) $iphub_key_class = " off"; else $iphub_key_class = null;
if($__FAUCET_DATA['n_daily']==0) $daily_value_class = " off"; else $daily_value_class = null;
if($__FAUCET_DATA['n_daily']==0) $__FAUCET_DATA['n_daily_enable'] = 0; else $__FAUCET_DATA['n_daily_enable'] = 1;
if($__FAUCET_DATA['n_capt']==0) $rc_class = ' hide'; else $rc_class = null;


$sl=array("n_daily_o","n_iphub","n_aab","n_capt","n_status","n_daily_enable");
if($coins_list) $coins_list = implode(",",$coins_list);
foreach($sl as $v){
if($__FAUCET_DATA[$v]==1) { 
$select["%".$v]='<select name="settings['.$v.']" class="select form-control"><option value="0" data-class="off">off</option><option value="1" selected data-class="on">on</option></select>';}
else
{$select["%".$v]='<select name="settings['.$v.']" class="select form-control off"><option value="0" selected data-class="off">off</option><option value="1" data-class="on">on</option></select>';}
}
} else { $hide = "hide"; } 
//////////
//
//  
$engine = array(
"%hide" => $hide,
"%key" => "CCBOX-".$__USER_DATA['u_hash'],
"%ccbox_coins" => $coins_list,
"%okey" => $__FAUCET_DATA['n_okey'],
"%skey" => $__FAUCET_DATA['n_skey'],
"%coins" => $coins['html'],
"%zones" => $__FAUCET_DATA['n_zones'],
"%zn_perc" => $__FAUCET_DATA['n_zones_perc'],
"%daily" => $__FAUCET_DATA['n_daily'],
"%hp" => $__FAUCET_DATA['n_hp'],
"%iphub_key_class" => $iphub_key_class,
"%db_value_class" => $daily_value_class,
"%iphub_key" => $__FAUCET_DATA['n_iphub_key'],
"%faucet_daily" => $daily_message,
"%rokey" => $__FAUCET_DATA['n_capt_okey'],
"%rskey" => $__FAUCET_DATA['n_capt_skey'],
"%rc_class" => $rc_class,
"%adv_faucet" => $__FAUCET_DATA['n_adv_faucet']
);	
//////////
//
// 
if($select) $engine = array_merge($engine,$select);
} else { 
//////////
//
//	

$__SECTION_SETTINGS[end($current)]['template']="signin.tmp.html";
}
} else $__SECTION_SETTINGS[end($current)]['template'] = "404.tmp.html";
?>