<?
if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
if(file_exists($_SERVER["DOCUMENT_ROOT"]."/core/config.php")) require_once($_SERVER["DOCUMENT_ROOT"]."/core/config.php"); 	
if(file_exists($_SERVER["DOCUMENT_ROOT"]."/core/functions.php")) require_once($_SERVER["DOCUMENT_ROOT"]."/core/functions.php"); 
if(file_exists($_SERVER["DOCUMENT_ROOT"]."/core/engine.php")) require_once($_SERVER["DOCUMENT_ROOT"]."/core/engine.php"); 

if($_POST&&$__USER_DATA['u_status']==2&&$__FAUCET_DATA['n_hash']==$__USER_DATA['u_hash']){
if(md5(md5($_POST['password']))==$__USER_DATA['u_password']) {

$__result=null;	

if($_POST['settings']) {	
$_POST['settings']['n_okey']=strip_tags(trim($_POST['settings']['n_okey']));
$_POST['settings']['n_skey']=strip_tags(trim($_POST['settings']['n_skey']));

$date = new DateTime();
$data = array(
'h' 	=> $__FAUCET_DATA['n_hash'],
'r' 	=> $__FAUCET_DATA['n_hash'],
'n' 	=> $date->getTimestamp(),
'k' 	=> functions::encrypt($_POST['settings']['n_okey'], $_POST['settings']['n_skey'], $date->getTimestamp())
);
$__out = json_decode(functions::ccbox("https://ccbox.io/api/user/",$data), true);


if($__out['code']==200) 
{
if($_POST['settings']['n_daily_enable']==0)	{ $_POST['settings']['n_daily']=0;  $_POST['settings']['n_daily_o']=0; }
foreach ($_POST['settings'] as $k => $v){
if($k=='n_hp'&&$v>100) $v=100;
if($k=='n_iphub'&&$v==1) if(!$_POST['settings']['n_iphub_key']) $v=0;
if($k=='n_adv_faucet') $v=addslashes($v);
if($k!='n_daily_enable') $__o[]= "`".$k."` = '".$v."'";	

}
$__settings = implode(",",$__o);

if($_POST['coins']) {
foreach ($_POST['coins'] as $k => $v){
$__l=null;
$__coins_d=null;
	foreach ($v as $i => $w){
	if($i=='c_faucet') $__sc[$k] = $w;	
	if($i=='c_min_pay') { $w=$functions::satoshi($w,true); if($w<10) $w=10; }
	if($i=='c_hp'&&$w>100) $w=100; 
	if($i=='c_hp'&&$w<0) $w=0;
	if($i=='c_redirect'&&$w==1) if(!$_POST['coins'][$k]['c_redirect_url']) $w=0;
	
	$__l[]= "`".$i."` = '".$w."'";	
	}
$__coins_d = implode(",",$__l);	
$__c[]= functions::replace("UPDATE `%p_coins` SET %d WHERE `c_coin` = '%c'",array("%p"=>PREFIX,"%d"=>$__coins_d,"%c"=>$k));
}
}

$scsq = null;
if($__sc)
{

foreach($__sc as $sc => $sv){
if($__SECTION_DATA[$sc]){ 
if($__SECTION_DATA[$sc]['s_status']!=$sv) $__s[]= functions::replace("UPDATE `%p_sections` SET `s_status` = '%sv' WHERE `s_alias` = '%al'",array("%p"=>PREFIX,"%sv"=>$sv,"%al"=>$sc)); 
} else {
	
if($sv==1){
	
if(!$__out['data']){
$date = new DateTime();
$data = array(
'h' 	=> $__FAUCET_DATA['n_hash'],
'n' 	=> $date->getTimestamp(),
'k' 	=> functions::encrypt($__FAUCET_DATA['n_okey'], $__FAUCET_DATA['n_skey'], $date->getTimestamp())
);
$__out = json_decode(functions::ccbox("https://ccbox.io/api/coins/",$data), true);}

if(FAUCET_SECTION) $faucet_section_alias = FAUCET_SECTION; else $faucet_section_alias = "faucets";
$__s[]= functions::replace("INSERT INTO `%p_sections` (`s_id`, `s_alias`, `s_name`, `s_title`, `s_desc`, `s_settings`, `s_parent`, `s_order`, `s_status`) VALUES (NULL, '%al', '%n', '%t', '%d', '{\"engine\":\"faucet.page.eng.php\",\"template\":\"faucet.page.tmp.html\"}', '%r', '0', '%sv')",array("%p"=>PREFIX,"%sv"=>$sv,"%al"=>$sc,"%r"=>$__SECTION_DATA[$faucet_section_alias]['s_id'],"%n"=>$__out['data'][$sc]['name']." Faucet","%t"=>$__out['data'][$sc]['name']." Faucet based on CCBOX.IO","%d"=>$__out['data'][$sc]['name']." Faucet - earn free ".$__out['data'][$sc]['name']." on ".$__FAUCET_DATA['n_sitename'])); 

}

}}}

if($__c) $__str_co = implode("; ",$__c); else $__str_co = null;
if($__s) $__str_sc = "; ".implode("; ",$__s); else $__str_sc = null;

$sql = functions::replace("UPDATE `%p_settings` SET `n_connect` = '1', %s WHERE `n_hash` = :h; %c %o",array("%p"=>PREFIX,"%s"=>$__settings,"%c"=>$__str_co,"%o"=>$__str_sc));

//$__result['error'] = $sql; echo json_encode($__result); exit();

$stmt =  $dbh->prepare($sql);
$stmt -> execute(array('h' => $__FAUCET_DATA['n_hash']));
$__result['success'] = 'Saved successfully.';
} else { 

$__result['error'] = 'Access denied, wrong CCBOX Keys.';
$__result['disabled'] = true; 

}
}
} else { $__result['error'] = 'Access denied, wrong password.';	 }
}
else
{
$__result['error'] = 'Access denied, check privilege settings.';	
}
if($__result) {  echo json_encode($__result); $dbh = null;  }
}
?>