<?php
if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
if(file_exists($_SERVER["DOCUMENT_ROOT"]."/core/config.php")) require_once($_SERVER["DOCUMENT_ROOT"]."/core/config.php");  
if(file_exists($_SERVER["DOCUMENT_ROOT"]."/core/functions.php")) require_once($_SERVER["DOCUMENT_ROOT"]."/core/functions.php"); 
if(file_exists($_SERVER["DOCUMENT_ROOT"]."/core/engine.php")) require_once($_SERVER["DOCUMENT_ROOT"]."/core/engine.php"); 

$a=0;
session_start();
ini_set('session.gc_maxlifetime', 900); 
if(!$_SESSION['out']){
$date = new DateTime();
$nonce = $date->getTimestamp();
$data = array(
'h' 	=> $__FAUCET_DATA['n_hash'],
'n' 	=> $date->getTimestamp(),
'k' 	=> functions::encrypt($__FAUCET_DATA['n_okey'], $__FAUCET_DATA['n_skey'], $nonce)
);
if($__out['code']=200) $_SESSION['out'] = json_decode(functions::ccbox("https://ccbox.io/api/balance/",$data), true);
}

if($_SESSION['out']['balance']){
foreach($_SESSION['out']['balance'] as $k => $v){
if($v>0) $bsql.=functions::replace("UPDATE `%p_coins` SET `c_max_pay` = '%b' WHERE `c_coin` = '%c'; ",array("%p"=>PREFIX,"%b"=>$v,"%c"=>$k));}
if($bsql) { $stmt =  $dbh->prepare($bsql);
			$stmt -> execute(); }
}


if(FAUCET_SECTION) $GLOBALS['salias'] = FAUCET_SECTION; else $GLOBALS['salias'] = "faucets";

$columns = array(
array( 'db' => 'c_coin','dt' => $a,
	  'formatter' => function( $d, $row ) {
           $v='<div class="text-left"><i class="fa fa-signal orange" aria-hidden="true"></i>&nbsp;<a href="/'.$GLOBALS['salias'].'/'.$d.'" style="color:#eee"><strong>'.strtoupper($d).'&nbsp;Faucet</strong></a></div>';
		   $GLOBALS['ccoin'] = $d;
		   return $v;
        }),
array( 'db' => 'c_min_pay','dt' => ++$a,
	  'formatter' => function( $d, $row ) {
           $v='<div class="text-left">'.functions::satoshi($d).'&nbsp;'.strtoupper($GLOBALS['ccoin']).'&nbsp;- '.functions::satoshi($d*1000000).'&nbsp;'.strtoupper($GLOBALS['ccoin']).'</div>';
		   $GLOBALS['minpay'] = $d;
		   return $v;
        }),
array( 'db' => 'c_timer','dt' => ++$a,
	  'formatter' => function( $d, $row ) {
           $v='<div><i class="fa fa-clock-o orange"></i>&nbsp;<span style="color:white">'.$d.'&nbsp;min</span></div>';
		   return $v;
        }),
array( 'db' => 'c_max_pay', 'dt' => ++$a,
	  'formatter' => function( $d, $row ) {
           $v='<span><div class="progress" style="height:12px"><div class="progress-bar" role="progressbar" style="width:'.functions::hperc($GLOBALS['minpay']*1000000,$d).'%" aria-valuenow="'.functions::hperc($GLOBALS['minpay']*1000000,$d).'" aria-valuemin="0" aria-valuemax="100"></div></div><small>'.functions::hperc($GLOBALS['minpay']*1000000,$d).'%</small></span>';
		   return $v;
        }),
array( 'db' => 'c_hp','dt' => ++$a,
	  'formatter' => function( $d, $row ) {
           $v='<span>no fees</span>';
		   return $v;
        }),
array( 'db' => 'c_hp', 'dt'  => ++$a,
	  'formatter' => function( $d, $row ) {
          $v='<span><a target="_blank" class="orange" href="https://ccbox.io/signin" style="color:#eee"><strong>ccbox.io</strong></a></span>';
		   return $v;
        }),

array( 'db' => 'c_faucet', 'dt'  => ++$a,
	  'formatter' => function( $d, $row ) {
           if($d==1) $v='<span><a class="btn btn-sm btn-action" href="/'.$GLOBALS['salias'].'/'.$GLOBALS['ccoin'].'">Join</a></span>'; else
		   $v='<span><a class="btn btn-sm btn-action disabled">Join</a></span>';
		   return $v;
        })
);
$sql_details = array(
    'user' => DBUSER,
    'pass' => DBPASS,
    'db'   => DBNAME,
    'host' => DBHOST
);


require($_SERVER["DOCUMENT_ROOT"].'/core/class.ssp.php' );
echo json_encode(
	SSPFull::simpleFull( $_GET, $sql_details, PREFIX.'_coins', 'c_order', $columns, "`c_faucet` != '0'")
);
}
?>