<?php
//////////
//
// 
if(functions::auth()) {
$sql = functions::replace("SELECT `u_ip` FROM `%p_users` WHERE `u_ip` = :ip",array("%p"=>PREFIX));
$stmt = $dbh->prepare($sql);
$stmt->execute(array("ip" => functions::getip()));
$counti = $stmt->rowCount();
if($counti>1) {$_POST=null; $d_ip_blocked = true;}
}
//////////
//
//	
if($__COINS_DATA[end($current)]){
if($__COINS_DATA[end($current)]['c_faucet']==1){
$result=null;
$__captccheck['block']=false;
$captblock = null;
//////////
//
//	
if($__FAUCET_DATA['n_capt']==1&&$__FAUCET_DATA['n_capt_okey']&&$__FAUCET_DATA['n_capt_skey'])
{
if(file_exists($_SERVER["DOCUMENT_ROOT"]."/core/recaptchalib.php")) require_once($_SERVER["DOCUMENT_ROOT"]."/core/recaptchalib.php"); else exit("core/recaptchalib.php not found");
$response = null;
$reCaptcha = new ReCaptcha($__FAUCET_DATA['n_capt_skey']);
$captblock = '<center><div class="g-recaptcha" data-theme="dark" data-sitekey="'.$__FAUCET_DATA['n_capt_okey'].'"></div></center><br/>';	
}
//////////
//
//
if($__FAUCET_DATA['n_daily']>0){	
if(file_exists(DATAPATH.'/market.txt')){$__cryptoapi = file_get_contents(DATAPATH.'/market.txt');} 
$___carr=json_decode($__cryptoapi, true);
if($___carr){
foreach ($___carr['data'] as $k => $v) {  
$__cac[strtolower($v['symbol'])]['price_usd'] = $v['quote']['USD']['price'];
}
$stmt = $dbh->query(functions::replace("SELECT `th_type`, `th_coin`, `th_amount`, `th_datetime` FROM `%p_trs_history` WHERE `th_type` = '0' AND UNIX_TIMESTAMP(CURRENT_DATE()) < th_datetime;",array("%p"=>PREFIX)))->fetchAll(PDO::FETCH_ASSOC); 
foreach ($stmt as $row) {
if($__cac[$row['th_coin']]['price_usd']){	
$___t = $___t + functions::satoshi($row['th_amount'])*$__cac[$row['th_amount']]['price_usd'];
$___a = functions::satoshi($row['th_amount']);
$___i = $___a*$__cac[$row['th_coin']]['price_usd'];		
if(strstr($___i,"E-")) $___i=sprintf('%.8F',$___i);
$___t=$___t+$___i;
} 	
if($___t) { $__dp = ( $___t * 100 ) / $__FAUCET_DATA['n_daily']; $___dpt = 100 - $__dp; if($___dpt<0) $___dpt = 0 ; } else { $___dpt=100; }	
if($___t>$__FAUCET_DATA['n_daily']&&$__FAUCET_DATA['n_daily_o']==1) $__dailycheck['block'] = 1;
if($___t>$__FAUCET_DATA['n_daily']&&$__FAUCET_DATA['n_daily_o']==0) { $__COINS_DATA[end($current)]['c_hp'] = 1; $__FAUCET_DATA['n_hp'] = 1; }
}}}
//////////
//
//	
$__ipchresult['block']=false;
if($__FAUCET_DATA['n_iphub']==1&&$__FAUCET_DATA['n_iphub_key']){
$__ipchresult = functions::iphub("http://v2.api.iphub.info/ip/".functions::getip(),$__FAUCET_DATA['n_iphub_key'],false);
$__ipchresult = json_decode($__ipchresult, true);
}
//////////
//
//
$event_message = '<div id="message_block"><p class="won center bordered_gr"><span id="countdown"></span></p></div>';
$dt = new DateTime();
$nt = $dt->getTimestamp();
$di = $__USER_DATA['u_session'] - $nt;
$ds = (int)$di-(int)$__COINS_DATA[end($current)]['c_timer'];
if($di<0) $di = 0;
//////////
//
// 
if($_POST){
if($__FAUCET_DATA['n_capt']==1) {
$response = $reCaptcha->verifyResponse($_SERVER["REMOTE_ADDR"],$_POST["g-recaptcha-response"]);
if(!$response->success) $__captccheck['block']=1; }
if($di == 0){

if(!$__ipchresult['block']){
if(!$__dailycheck['block']){
if(!$__captccheck['block']){	
if($__COINS_DATA[end($current)]['c_redirect']==1&&$__COINS_DATA[end($current)]['c_redirect_url']){ 
header("location: ".$__COINS_DATA[end($current)]['c_redirect_url']); 
} else {
 $result = functions::roll($dbh, $__FAUCET_DATA, $__COINS_DATA, $__USER_DATA, $current); 
if($result[0]==1) $result_message = '<p class="won center bordered" id="bl">Your reward: '.functions::satoshi($result[1]).' %coin_symb</p>';
else $result_message = '<p class="err center bordered" id="bl">'.$result[1].'</p>';
$event_message = '<div id="message_block">'.$result_message.'</div>';
$di = $__USER_DATA['u_session'] - $nt;
}
} else $event_message = '<div id="message_block"><p class="err center bordered" id="bl"><i class="fa fa-info-circle"></i> Invalid captcha code</p></div>';  
} else $event_message = '<div id="message_block"><p class="err center bordered"><i class="fa fa-info-circle"></i> Daily limit reached, come back tomorrow.</p></div>';  
} else $event_message = '<div id="message_block"><p class="err center bordered" id="bl"><i class="fa fa-info-circle"></i> Your IP '.functions::getip().' has been banned by IPHub.info</p></div>'; 
} else { $m=(int)$ds/60; $m=round($m,0); $event_message = '<div id="message_block"><p class="err center bordered" id="bl"><i class="fa fa-info-circle"></i> Try again after '.$m.' minutes!</p></div>';  
}
}
//////////
//
//
//
if($__COINS_DATA[end($current)]['c_redirect']==1&&$__COINS_DATA[end($current)]['c_redirect_url'] && $di == 0 && !$__MAINTENANCE){ 
$ref = $_SERVER['HTTP_REFERER'];
if($__COINS_DATA[end($current)]['c_redirect_backward_url']) $__receive = $__COINS_DATA[end($current)]['c_redirect_backward_url']; else $__receive = $__COINS_DATA[end($current)]['c_redirect_url'];
if (strpos($ref, $__receive) !== FALSE && !$__ipchresult['block']) {
$result = functions::roll($dbh, $__FAUCET_DATA, $__COINS_DATA, $__USER_DATA, $current);
if($result[0]==1) $result_message = '<p class="won center bordered" id="bl">Your reward: '.functions::satoshi($result[1]).' %coin_symb</p>';
else $result_message = '<p class="err center bordered" id="bl">'.$result[1].'</p>';
$di = $__USER_DATA['u_session'] - $nt;
$event_message = '<div id="message_block">'.$result_message.'</div>';
} 
}
//////////
//
//
//
if(!$result){
$countdown_start = '<script>$(document).ready(function() {
$("#claim").prop("disabled",true); $("#claim").addClass("disabled");
function cready() { $("#claim").prop("disabled",false); $("#claim").removeClass("disabled");$("#message_block").html("<p class=\"won center bordered\" id=\"bl\"><i class=\"fa fa-info-circle\"></i> Ready to claim!</p>");
}';
$countdown_start.= '$("#countdown").countdown({until: +'.$di.', padZeroes: true,   format: "HMS", significant: 4, onExpiry: cready});';
if($di==0&&!$_POST&&!$__MAINTENANCE) $countdown_start.= " cready();";
if($__captccheck['block']&&!$__MAINTENANCE) $countdown_start.= " setTimeout(function() { cready(); }, 3000);";
$countdown_start.= '});</script>';
}
else
{
$countdown_start = '<script>$(document).ready(function() {
$("#claim").prop("disabled",true); $("#claim").addClass("disabled");
setTimeout(function() {';
$countdown_start.= ' window.location = "/faucets/'.end($current).'"; ';
$countdown_start.= '}, 5000);
});</script>';
}
$prize_table = '
<table class="table table-striped table-bordered">
<thead>
<tr>
<th>1000-9685</th>
<th>9686-9885</th>
<th>9886-9985</th>
<th>9986-9993</th>
<th>9994-9997</th>
<th>9998-9999</th>
<th>10000</th>
</tr>
</thead>
<tbody>
<tr>
<td>'.$functions::satoshi($__COINS_DATA[end($current)]['c_min_pay']).' %coin_symb</td>
<td>'.$functions::satoshi($__COINS_DATA[end($current)]['c_min_pay']*10).' %coin_symb</td>
<td>'.$functions::satoshi($__COINS_DATA[end($current)]['c_min_pay']*100).' %coin_symb</td>
<td>'.$functions::satoshi($__COINS_DATA[end($current)]['c_min_pay']*1000).' %coin_symb</td>
<td>'.$functions::satoshi($__COINS_DATA[end($current)]['c_min_pay']*10000).' %coin_symb</td>
<td>'.$functions::satoshi($__COINS_DATA[end($current)]['c_min_pay']*100000).' %coin_symb</td>
<td>'.$functions::satoshi($__COINS_DATA[end($current)]['c_min_pay']*1000000).' %coin_symb</td>
</tr>
</tbody>
</table>';
//////////
//
// 
if($__FAUCET_DATA['n_adv_faucet']) $adv_faucet = "<p>".$__FAUCET_DATA['n_adv_faucet']."</p>"; else $adv_faucet = null;
//////////
//
// 
if($__MAINTENANCE) { $event_message = '<div id="message_block"><p class="err center bordered" id="bl"><i class="fa fa-info-circle"></i> MAINTENANCE MODE. Try again later</p></div>';  $captblock = null;  $countdown_start = null;}
if(file_exists($_SERVER["DOCUMENT_ROOT"]."/templates/".TEMPLATE."/seo/faucet-".$__COINS_DATA[end($current)]['c_coin'].".html")) $seo = file_get_contents($_SERVER["DOCUMENT_ROOT"]."/templates/".TEMPLATE."/seo/faucet-".$__COINS_DATA[end($current)]['c_coin'].".html"); else $seo = null;

$claim_btn = '<button id="claim" name="claim" class="btn btn-action">CLAIM '.strtoupper($__COINS_DATA[end($current)]['c_coin']).'</button>';

if(!functions::auth()){ $countdown_start = null; $claim_btn = '<a class="btn btn-action" href="/">REGISTER</a>'; $event_message = '<div id="message_block"><p class="won center bordered" id="bl"><i class="fa fa-info-circle"></i> Register first</p></div>';}

if($d_ip_blocked){
$event_message = '<div id="message_block"><p class="err center bordered" id="bl"><i class="fa fa-info-circle"></i> Your IP address is already registered. Change your IP.</p></div>';  $captblock = null;  $countdown_start = null;	
$claim_btn = '<button class="btn btn-action disabled" disabled>CLAIM '.strtoupper($__COINS_DATA[end($current)]['c_coin']).'</button>'; 
}

$engine = array(
"%countdown_start" 	=> $countdown_start,
"%event_message" 	=> $event_message,				
"%prize_table" 		=> $prize_table,				
"%coin_name" 		=> $__COINS_DATA[end($current)]['c_name'],
"%coin_symb" 		=> strtoupper($__COINS_DATA[end($current)]['c_coin']),
"%coin_time" 		=> strtoupper($__COINS_DATA[end($current)]['c_timer']),
"%captcha"   		=> $captblock,
"%seo" 				=> $seo,
"%adv_faucet"		=> $adv_faucet,
"%claim_btn"		=> $claim_btn
);
//////////
//
// 
} else $__SECTION_SETTINGS[end($current)]['template'] = "404.tmp.html";
} else $__SECTION_SETTINGS[end($current)]['template'] = "404.tmp.html";


?>