<?php
//////////
//
// 
if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
if(file_exists($_SERVER["DOCUMENT_ROOT"]."/core/config.php")) require_once($_SERVER["DOCUMENT_ROOT"]."/core/config.php"); 
if($_COOKIE[COOKIE_NAME]) unset($_COOKIE[COOKIE_NAME]);
setcookie(COOKIE_NAME,"",time()-100,"/",HOST,COOKIE_HTTPS,COOKIE_HTTP_ONLY);
echo json_encode($__result);

}
?>