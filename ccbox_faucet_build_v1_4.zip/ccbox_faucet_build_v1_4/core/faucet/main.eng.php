<?php
if(functions::auth()) { 
if(FAUCET_SECTION) $faucet_section_alias = FAUCET_SECTION; else $faucet_section_alias = "faucets";
header ("location: /".$faucet_section_alias);
}
?>