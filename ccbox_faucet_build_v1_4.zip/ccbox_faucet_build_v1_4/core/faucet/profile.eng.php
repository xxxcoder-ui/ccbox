<?php
//////////
//
//
// 
if(functions::auth()) {
if(!$lds) $lds = 30; 
$lds_dt = (60*60*24)*$lds;
$difr = time()-$lds_dt;
$sql = functions::replace("SELECT `th_id`, `th_user_id`, `th_type`, `th_coin`, `th_amount`, `th_fee`, `th_part_id`, `th_datetime` FROM `%p_trs_history` WHERE `th_user_id` = :u",array("%p"=>PREFIX));
$stmt = $dbh->prepare($sql);
$stmt->execute(array("u" => $__USER_DATA['u_id']));
$count = $stmt->rowCount();
if($count>0) { 	 
foreach ($stmt as $row) {
if($row['th_type']==0){		
$_stat['total'][$row['th_coin']] = $_stat['total'][$row['th_coin']]+$row['th_amount'];
$_stat['claim'][$row['th_coin']] ++;
if(is_string($row['th_datetime'])) $timestamp = $row['th_datetime']; else $timestamp = strtotime($row['th_datetime']); 
 $_stat['lastd'][$row['th_coin']] = date("Y-m-d H:i:s",$timestamp);
$_stat['shtml'][$row['th_coin']] = '<tr class="izu"><td class="center hcol_500">'.strtoupper($row['th_coin']).'</td><td class="center">'.functions::satoshi($_stat['total'][$row['th_coin']]).' '.strtoupper($row['th_coin']).'</td><td class="center hcol_500">'.$_stat['claim'][$row['th_coin']].'</td><td class="center">'.$_stat['lastd'][$row['th_coin']].'</td></tr>';
}
if($row['th_type']==1){	
if($row['th_datetime']>$difr) {
$_refs['total'][$row['th_coin']] = $_refs['total'][$row['th_coin']]+$row['th_amount'];
$_refs['claim'][$row['th_coin']]++;
$_refs['refer'][$row['th_coin']][] = $row['th_part_id'];
}
}
}
}
if($_stat['shtml']) $_stat_table = '
<table class="table table-bordered table-striped"><thead><tr><th class="center hcol_500">Coin</th><th class="center">Total Sended</th><th class="center hcol_500">Total claims</th><th class="center">Last Sent</th></tr></thead><tbody>'.implode(" ",$_stat['shtml']).'</tbody></table>';
//////////
//
// 
//////////
foreach(functions::refperc() as $k => $v){
$perc_table[0].= '<th class="center" width="14.2857%" style="padding-left:2px">&gt; '.$k.'</th>'; $perc_table[1].= '<td class="center">'.$v.'%</td>'; }
foreach($__COINS_DATA as $v){
if($v['c_faucet']==1) {
if(!$_refs['claim'][$v['c_coin']]) $_refs['claim'][$v['c_coin']] = 0;
if($_refs['refer'][$v['c_coin']]) $ref_count=count(array_unique($_refs['refer'][$v['c_coin']])); else $ref_count=0;	
$rc_rp = functions::refperc($ref_count,false);
if(is_array($rc_rp)) $rc_rp = 1;
$_ref_table.= '<tr class="izu"><td class="center">'.strtoupper($v['c_coin']).'</td><td class="center hcol_500">'.$ref_count.'</td><td class="center">'.functions::satoshi($_refs['total'][$v['c_coin']]).' '.strtoupper($v['c_coin']).'</td><td class="center hcol_500">'.$_refs['claim'][$v['c_coin']].'</td><td class="center">'.$rc_rp.'%</td></tr>';
}
}
if($__FAUCET_DATA['n_adv_faucet']) $adv_faucet = $__FAUCET_DATA['n_adv_faucet']."<br/>"; else $adv_faucet = null;
$rl = $_SERVER['REQUEST_SCHEME']."://".$_SERVER['HTTP_HOST']."?ref=".$__USER_DATA['u_id'];
$engine = array("%stat_table" => $_stat_table, "%ref_table" => $_ref_table, "%perc_table_header" => $perc_table[0], "%perc_table_body" => $perc_table[1], "%key" => "CCBOX-".$__USER_DATA['u_hash'], "%name" => $__USER_DATA['u_name'], "%rlink" => $rl, "%adv_faucet" => $adv_faucet, "%last_days" => $lds);	
}
else
{
header("location: /");	
	
}
?>