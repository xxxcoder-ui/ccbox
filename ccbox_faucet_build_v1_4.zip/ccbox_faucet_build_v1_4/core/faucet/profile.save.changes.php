<?
if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
if(file_exists($_SERVER["DOCUMENT_ROOT"]."/core/config.php")) require_once($_SERVER["DOCUMENT_ROOT"]."/core/config.php"); 	
if(file_exists($_SERVER["DOCUMENT_ROOT"]."/core/functions.php")) require_once($_SERVER["DOCUMENT_ROOT"]."/core/functions.php"); 
if(file_exists($_SERVER["DOCUMENT_ROOT"]."/core/engine.php")) require_once($_SERVER["DOCUMENT_ROOT"]."/core/engine.php"); 

if($_POST["name"]){
	
$_POST["name"] = strip_tags(trim($_POST["name"]));
if(strlen($_POST["name"])>50) $_POST["name"] = substr($_POST["name"], 0, 50);

$sql = functions::replace("UPDATE `%p_users` SET `u_name` = :n WHERE `u_id` = :u; UPDATE `%p_trs_history` SET `th_user_name` = :n WHERE `th_user_id` = :u;",array("%p"=>PREFIX));
$stmt =  $dbh->prepare($sql);
$stmt -> execute(array('u' => $__USER_DATA['u_id'], 'n' => $_POST["name"]));
$count = $stmt->rowCount();
$__result['success'] = 'Saved successfully.';
if($count>0){ $__result['success'] = 'Saved successfully.'; }
}

if($__result) {  echo json_encode($__result); $dbh = null;  }

}
?>