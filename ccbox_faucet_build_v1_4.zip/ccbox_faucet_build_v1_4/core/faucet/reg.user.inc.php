<?
if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
if(file_exists($_SERVER["DOCUMENT_ROOT"]."/core/config.php")) require_once($_SERVER["DOCUMENT_ROOT"]."/core/config.php"); 	
if(file_exists($_SERVER["DOCUMENT_ROOT"]."/core/functions.php")) require_once($_SERVER["DOCUMENT_ROOT"]."/core/functions.php"); 
if(file_exists($_SERVER["DOCUMENT_ROOT"]."/core/engine.php")) require_once($_SERVER["DOCUMENT_ROOT"]."/core/engine.php"); 
//////////
//
// 
if($_POST["key"]){
$_POST["key"] = strip_tags(	trim($_POST["key"]) );
$_POST["key"] = preg_replace("/ /", "", $_POST["key"]);
$_POST["key"] = preg_replace("/CCBOX-/", "", $_POST["key"]);
//////////
//
// 
$sql = functions::replace("SELECT `u_id`, `u_hash`, `u_session`, `u_status`  FROM `%p_users` WHERE `u_hash` = :h limit 1",array("%p"=>PREFIX));
$stmt = $dbh->prepare($sql);
$stmt->execute(array('h' => $_POST["key"]));
$hash = $stmt->rowCount();
//////////
//
// 
if($hash>0){
foreach ($stmt as $row)
{
functions::fsetcookie($row['u_hash'],$row['u_id'],date("Y/m/d H:i:s",strtotime($row['u_session'])));	
if($row['u_status']==2) {  $__result['redirect'] = "/admin"; } else {  $__result['redirect'] = "/profile";	}
$__result['success'] = '<i class="fa fa-cog fa-spin" aria-hidden="true"></i> Welcome back! Redirecting...';

}
}
else
{
//////////
//
// 	
$__result = null;
//////////
//
// 
$date = new DateTime();
$data = array(
'h' 	=> $__FAUCET_DATA['n_hash'],
'r' 	=> $_POST["key"],
'n' 	=> $date->getTimestamp(),
'k' 	=> functions::encrypt($__FAUCET_DATA['n_okey'], $__FAUCET_DATA['n_skey'],$date->getTimestamp())
);
//////////
//
// 
$__out = json_decode(functions::ccbox("https://ccbox.io/api/user/",$data), true);

//////////
//
// 

if($__out['code']==200) 
{
if($_COOKIE[COOKIE_REF_NAME]) $rpid = preg_replace('~[^0-9]+~','',$_COOKIE[COOKIE_REF_NAME]); else $rpid = 0;	
if(!$__USER_DATA['zone']) $__USER_DATA['zone'] = "";	
$sql = functions::replace("INSERT INTO `%p_users` (`u_id`, `u_hash`, `u_ip`, `u_geo`, `u_session`, `u_name`, `u_email`, `u_password`, `u_reg_datetime`, `u_last_online`, `u_ref_id`, `u_settings`, `u_status`) VALUES (NULL, :h, :ip, :geo, UNIX_TIMESTAMP(), '', '', '', UNIX_TIMESTAMP(), UNIX_TIMESTAMP(), :rid, '', '1');",array("%p"=>PREFIX));												
$stmt =  $dbh->prepare($sql);
$stmt -> execute(array('h' => $_POST["key"], 'ip' => functions::getip(), 'geo' => $__USER_DATA['zone'], 'rid' => $rpid));
$d = $dbh->lastInsertId();
if($_COOKIE[COOKIE_NAME]) unset($_COOKIE[COOKIE_NAME]);
functions::fsetcookie($_POST["key"],$d,date("Y/m/d H:i:s"));
$__result['redirect'] = "/faucets";	
}
}
if($__out['code']==200) $__result['success'] = '<i class="fa fa-cog fa-spin" aria-hidden="true"></i> You are registered successfully! Redirecting...'; else $__result['error'] = 'CCBOX KEY not found! This faucet requires a <a rel="nofollow" target="_blank" href="https://ccbox.io/signup">CCBOX.IO</a> account to claim.';
if($__result) {  echo json_encode($__result); $dbh = null;  }
}
}
?>