<?php


if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
if(file_exists($_SERVER["DOCUMENT_ROOT"]."/core/config.php")) require_once($_SERVER["DOCUMENT_ROOT"]."/core/config.php");  
if(file_exists($_SERVER["DOCUMENT_ROOT"]."/core/functions.php")) require_once($_SERVER["DOCUMENT_ROOT"]."/core/functions.php"); 
if(file_exists($_SERVER["DOCUMENT_ROOT"]."/core/engine.php")) require_once($_SERVER["DOCUMENT_ROOT"]."/core/engine.php"); 

$a=0;

$columns = array(
array( 'db' => 'th_id','dt' => $a),
array( 'db' => 'th_user_id','dt' => ++$a,
	  'formatter' => function( $d, $row ) {
           $v='<div class="text-left"><i class="fa fa-user orange"></i>&nbsp;#'.strtoupper($d).'</div>';
		   $GLOBALS['uid'] = $d;
		   return $v;
        }),
array( 'db' => 'th_user_name','dt' => ++$a,
	  'formatter' => function( $d, $row ) {
		   if(!$d) $d = "user_".$GLOBALS['uid'];
           $v='<div class="text-left"><i class="fa fa-user orange"></i>&nbsp;<span style="color:white">'.$d.'</span></div>';
		   return $v;
        }),
array( 'db' => 'th_datetime', 'dt' => ++$a,
	  'formatter' => function( $d, $row ) {
           $v='<span>'.date("d.m.Y H:i:s",$d).'</span>';
		  
		   return $v;
        }),
array( 'db' => 'th_coin','dt' => ++$a,
	  'formatter' => function( $d, $row ) {
           $v='<span>'.strtoupper($d).'</span>';
		   $GLOBALS['ccoin'] = $d;
		   return $v;
        }),
array( 'db' => 'th_type', 'dt'  => ++$a,
	  'formatter' => function( $d, $row ) {
           $v='<span><i class="fa fa-plus-circle orange" aria-hidden="true"></i>&nbsp;Reward</span>'; 
		   return $v;
        }),

array( 'db' => 'th_amount', 'dt'  => ++$a,
	  'formatter' => function( $d, $row ) {
           $v='<span>'.functions::satoshi($d).'&nbsp;'.strtoupper($GLOBALS['ccoin']).'</span>';
		   return $v;
        }),

array( 'db' => 'th_fee', 'dt'  => ++$a,
	  'formatter' => function( $d, $row ) {
           $v='<span><i class="fa fa-check orange"></i>&nbsp;Complete</span>';
		   return $v;
        })
);
$sql_details = array(
    'user' => DBUSER,
    'pass' => DBPASS,
    'db'   => DBNAME,
    'host' => DBHOST
);


require($_SERVER["DOCUMENT_ROOT"].'/core/class.ssp.php' );
echo json_encode(
	SSPFull::simpleFull( $_GET, $sql_details, PREFIX.'_trs_history', 'th_datetime', $columns, "`th_type` = '0'")
);
}
?>