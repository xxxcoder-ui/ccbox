<?
if (!class_exists('functions')):

class functions {
	
public static function satoshi($a,$b = false)
	{
		if ($b) {
			$a = preg_replace('/ /','',$a);
			$a = sprintf("%.8F",$a);
			$a = preg_replace('~[^0-9]+~','',$a);
			$a = ltrim($a,"0"); 
		} else { 
			$s = $a / 100000000 ;
			$a = sprintf('%.8f', $s);
			}
		return $a;	
}

public static function replace($str,$arr){
			if(!$arr) return false; if(!$str) return false;
			foreach($arr as $k => $v){ $str = preg_replace("/".$k."/",$v,$str); }
			return $str;
}

public static function build_tree($c,$parent_id,$only_parent = false,$class = false,$n = 0,$s = false,$u = false){
    $_btn_class = null;
			if(is_array($c) and isset($c[$parent_id])){
				
				if($class&&$n==0) { $tree = '<ul class="'.$class.'">';  $path = null; } else { $tree = '<ul class="dropdown-menu">'; $path = $c['parent'][$parent_id]['s_alias']."/"; $n++; }
				if($only_parent==false){
					foreach($c[$parent_id] as $cr){
						
						$_btn_class = null; if($s[$cr['s_alias']]['button_class']) $_btn_class = $s[$cr['s_alias']]['button_class'];
						
						
						
						if($c[$cr['s_id']]) $tree .= '<li class="dropdown"><a href="/'.$path.$cr['s_alias'].'" class="dropdown-toggle" data-toggle="dropdown">'.$cr['s_name'].' <b class="caret"></b></a>';
						else $tree .= '<li><a class="'.$_btn_class.'" href="/'.$path.$cr['s_alias'].'">'.$cr['s_name']."</a>";
						$tree .=  functions::build_tree($c,$cr['s_id']);
						$tree .= '</li>';
						
						
						
					}
				}elseif(is_numeric($only_parent)){
					$cr = $c[$parent_id][$only_parent];
					$tree .= '<li>'.$cr['s_name'];
					$tree .=  functions::build_tree($c,$cr['s_id']);
					$tree .= '</li>';
				}
				$tree .= '</ul>';
			
			}
			else return null;
			return $tree;
}
 
public static function mb_ucfirst($str, $encoding='UTF-8')
    {
			$str = mb_ereg_replace('^[\ ]+', '', $str);
			$str = mb_strtoupper(mb_substr($str, 0, 1, $encoding), $encoding).
				   mb_substr($str, 1, mb_strlen($str), $encoding);
			return $str;
    }

public static function getip() {
			if (isset($_SERVER["HTTP_X_FORWARDED_FOR"])) {
			return $_SERVER["HTTP_X_FORWARDED_FOR"];
			} else if (isset($_SERVER["REMOTE_ADDR"])) {
			return $_SERVER["REMOTE_ADDR"];
			} else if (isset($_SERVER["HTTP_CLIENT_IP"])) {
			return $_SERVER["HTTP_CLIENT_IP"];
			}
			return "";
		}

public static function fsetcookie($h,$u,$t,$l=false,$p=false){
			$cookie_array = array(
			'uh'    =>   $h,
			'uid'   =>   $u,
			'uip'   =>   functions::getip(),
			'ts'    =>   $t,
			'ul'    =>   $l,
			'up'    =>   $p
			);							
			$cookie_str=http_build_query($cookie_array);
			setcookie(COOKIE_NAME,$cookie_str,time()+300000,"/",HOST,COOKIE_HTTPS,COOKIE_HTTP_ONLY); 
}

public static function getzones($z){
			if(!$z) return false;
			$z = preg_split("/,/",strip_tags(trim($z)));
			foreach ($z as $v){ if(strlen(trim($v))==2) $r[] = strtoupper($v);  }
			return $r;
}


public static function roll($dbh =  false, $__FAUCET_DATA, $__COINS_DATA,  $__USER_DATA, $current) {			

			if(!$__COINS_DATA[end($current)]) return false;
			if($__COINS_DATA[end($current)]['c_hp']>0)
			$hp = $__COINS_DATA[end($current)]['c_hp'];	else
			$hp = $__FAUCET_DATA['n_hp'];
			if($__FAUCET_DATA['n_zones']&&$__FAUCET_DATA['n_zones_perc']) { $fz = functions::getzones($__FAUCET_DATA['n_zones']);
			if($__USER_DATA['zone'] && count($fz>0) && in_array($__USER_DATA['zone'],$fz)) $hp = $hp + $__FAUCET_DATA['n_zones_perc']; }
			if(!$hp) $hp = 1; if($hp>=100) $hp=99; $hp--;

			$ap = range(100,1); $v = 1;
			
			for ($i=1; $i<8; $i++){ $v = $v * (int)$ap[$hp]; $vad[]=sprintf('%.8f', $v); }
			
			$rewards = array(		
			$vad[6] => $__COINS_DATA[end($current)]['c_min_pay'],
			$vad[5] => $__COINS_DATA[end($current)]['c_min_pay']*10,
			$vad[4] => $__COINS_DATA[end($current)]['c_min_pay']*100,
			$vad[3] => $__COINS_DATA[end($current)]['c_min_pay']*1000,
			$vad[2] => $__COINS_DATA[end($current)]['c_min_pay']*10000,
			$vad[1] => $__COINS_DATA[end($current)]['c_min_pay']*100000,
			$vad[0] => $__COINS_DATA[end($current)]['c_min_pay']*1000000			   
			);
				
			$total_weight = 0;
			$nrewards = array();
			$reward = array();
			
			foreach ($rewards as $w => $r) {
			$reward[0] = $w;
			$reward[1] = $r;    
			if (count($reward) < 2) {
			$reward[1] = $reward[0];
			$reward[0] = 1;
			}  
			$total_weight += floatval($reward[0]);
			$nrewards[] = $reward;
			}
			
			$rewards = $nrewards;
			if (count($rewards) > 1) {
			$possible_rewards = array();
			foreach ($rewards as $r) {
			$chance_per = 100 * $r[0]/$total_weight;
			if ($chance_per < 0.1)
			$chance_per = '< 0.1%';
			else
			$chance_per = round(floor($chance_per*10)/10, 1).'%';		
			$possible_rewards[] = $r[1]." ($chance_per)";
			}
			} else {
			$possible_rewards = array($rewards[0][1]);
			}

			$r = mt_rand()/mt_getrandmax();
			$t = 0;
			foreach ($rewards as $reward) {
			$t += floatval($reward[0])/$total_weight;
			if ($t > $r) {
				break;
			}
			}
			if (strpos($reward[1], '-') !== false) {
			$reward_range = explode('-', $reward[1]);
			$from = floatval($reward_range[0]);
			$to = floatval($reward_range[1]);
			$reward = mt_rand($from, $to);
			} else {
			$reward = floatval($reward[1]);
			}
			
			if($reward && $dbh) {			
			$date = new DateTime();
			$data = array(
			'h' 	=> $__FAUCET_DATA['n_hash'],
			'n' 	=> $date->getTimestamp(),
			'r'		=> $__USER_DATA['u_hash'],
			'c'		=> $__COINS_DATA[end($current)]['c_coin'],
			'a'		=> $reward,
			'k' 	=> functions::encrypt($__FAUCET_DATA['n_okey'], $__FAUCET_DATA['n_skey'], $date->getTimestamp())
			);
			$__out = json_decode(functions::ccbox("https://ccbox.io/api/transfer/",$data), true);			
			
			if($__out['code']==200){			
			if($__USER_DATA['u_ref_id']>0)
			{
			   
			$ref_count = $dbh->query(functions::replace("SELECT COUNT(th_part_id) FROM `%p_trs_history` WHERE `th_user_id` = '%i' AND `th_type` = '1' AND `th_coin` = '%c' AND `th_datetime` > (UNIX_TIMESTAMP() - 2592000) GROUP BY `th_part_id`",array("%p"=>PREFIX,"%i"=>$__USER_DATA['u_ref_id'],"%c"=>strtolower(end($current)))))->fetchAll(PDO::FETCH_ASSOC);
			
			
			$ref_hash = $dbh->query(functions::replace("SELECT `u_hash` FROM `%p_users` WHERE `u_id` = '%i'",array("%p"=>PREFIX,"%i"=>$__USER_DATA['u_ref_id'])))->fetchAll(PDO::FETCH_ASSOC);																									
			$ram  = functions::refperc(count($ref_count),$reward);
	
			
			$rsql = functions::replace("INSERT INTO `%p_trs_history` (`th_id`, `th_user_id`, `th_user_name`, `th_type`, `th_coin`, `th_amount`, `th_fee`, `th_part_id`, `th_datetime`) 
			VALUES (NULL, '%rid', '', '1', :co, '%ram', '0', :id, UNIX_TIMESTAMP());",array("%p"=>PREFIX,"%ram"=>$ram,"%rid"=>$__USER_DATA['u_ref_id']));
			
			
			$date = new DateTime();
			$data = array(
			'h' 	=> $__FAUCET_DATA['n_hash'],
			'n' 	=> $date->getTimestamp(),
			'r'		=> $ref_hash[0]['u_hash'],
			'c'		=> $__COINS_DATA[end($current)]['c_coin'],
			'a'		=> $ram,
			'k' 	=> functions::encrypt($__FAUCET_DATA['n_okey'], $__FAUCET_DATA['n_skey'], $date->getTimestamp())
			);
			$__outr = json_decode(functions::ccbox("https://ccbox.io/api/transfer/",$data), true);

			
			if($__outr['code']!=200){ $rsql = null;	}
			}
				
			$sql = functions::replace("UPDATE `%p_users` SET `u_session` = UNIX_TIMESTAMP() + :tm, `u_last_online` = UNIX_TIMESTAMP(), `u_ip` = :ip WHERE `u_id` = :id;
			INSERT INTO `%p_trs_history` (`th_id`, `th_user_id`, `th_user_name`, `th_type`, `th_coin`, `th_amount`, `th_fee`, `th_part_id`, `th_datetime`) 
			VALUES (NULL, :id, :nm, '0', :co, :re, '0', '0', UNIX_TIMESTAMP()); ".$rsql,array("%p"=>PREFIX));
			$stmt = $dbh->prepare($sql);
			$stmt->execute(array("id"=>$__USER_DATA['u_id'],"nm"=>$__USER_DATA['u_name'],"ip"=>functions::getip(),"co"=>strtolower(end($current)),"re"=>$reward,"tm"=>$__COINS_DATA[end($current)]['c_timer']*60));
			$count = $stmt->rowCount();
	
			return array(1,$reward); 

			} else return array(0,$__out['message']);	
			} else return array(0,"Database Error");
			
}




public static function refperc($rc = false,$ra = false) {
			$perc = array(0=>1,5=>2,10=>4,50=>20,100=>40,500=>60,1000=>100);
			if(!$ra) { if($rc>0) { foreach($perc as $k => $v){if($rc > $k) $r = $v;} return $r; } else return $perc;
			} else {
			foreach($perc as $k => $v){if($rc > $k) $r = $v;}
			if($r < 100) $a = ceil(($ra * $r) / 100); else $a = $ra;
			if($a < 1) $a = 1; return $a;}			
}



public static function encrypt( $encrypt, $key, $nonce ) {
			if(!$key || !$encrypt) return false;
			if(strlen($key) != 32) return false;
			$encrypt = md5(md5($nonce.$encrypt));
			$encrypt = serialize($encrypt);
			$iv = mcrypt_create_iv(mcrypt_get_iv_size(MCRYPT_RIJNDAEL_256, MCRYPT_MODE_CBC), MCRYPT_DEV_URANDOM);
			$key = pack('H*', $key);
			$mac = hash_hmac('sha256', $encrypt, substr(bin2hex($key), -32));
			$passcrypt = mcrypt_encrypt(MCRYPT_RIJNDAEL_256, $key, $encrypt.$mac, MCRYPT_MODE_CBC, $iv);
			$encoded = base64_encode($passcrypt).'|'.base64_encode($iv);
			return $encoded;
}



public static function auth($dbh =  false, $l = false, $p = false){	
			if($_COOKIE[COOKIE_NAME]){
			parse_str($_COOKIE[COOKIE_NAME], $_ucookie);
			if(!$_ucookie['uh']) return false;
			if($dbh && $l && $p) { 
			$auth = $dbh->query(functions::replace("SELECT `u_hash` FROM `%p_users` WHERE `u_hash` = '%h' AND `u_email` = '%e' AND `u_password` = '%w' ",array("%p"=>PREFIX,"%h"=>$_ucookie['uh'],"%e"=>$l,"%w"=>$p)))->fetch(PDO::FETCH_ASSOC);
			if($auth['u_hash']) { if($_COOKIE[COOKIE_NAME]) unset($_COOKIE[COOKIE_NAME]);
			functions::fsetcookie($_ucookie['uh'],$_ucookie['uid'],date("Y/m/d H:i:s",strtotime($_ucookie['ts'])),$l,$p); 
			return $_ucookie; 
			}else return false;
			} else return $_ucookie;		
			}
			else
			return false;
}

public static function iphub($url,$key,$__post=false){
			if(!$key) return false;
			$ch = curl_init();      
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); 
			if($__post==true) curl_setopt($ch, CURLOPT_POST, 1); 
			curl_setopt($ch, CURLOPT_URL, $url);   
			curl_setopt($ch,CURLOPT_HTTPHEADER,array("X-Key: ".$key));
			$result = curl_exec($ch);   
			curl_close($ch);   
			return $result;  
}	

public static function ccbox( $path, $data ){
			$data_str = http_build_query($data);
			if( $curl = curl_init() ) {	
			curl_setopt($curl, CURLOPT_URL, $path);
			curl_setopt($curl, CURLOPT_RETURNTRANSFER,true);
			curl_setopt($curl, CURLOPT_POST, true);
			curl_setopt($curl, CURLOPT_POSTFIELDS, $data_str);
			curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
			curl_setopt($curl, CURLOPT_AUTOREFERER, true);
			curl_setopt($curl, CURLOPT_CONNECTTIMEOUT, 120);
			curl_setopt($curl, CURLOPT_TIMEOUT, 120);
			curl_setopt($curl, CURLOPT_MAXREDIRS, 2);
			curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
			curl_setopt($curl, CURLOPT_REFERER, $_SERVER['HTTP_HOST']);
			$result = curl_exec($curl);	
			curl_close($curl);
			return $result;}
}

public static function hperc($a,$b){
		if($a==0) return 0; if($b==0) return 0;
		$r = ($b / $a) * 100;
		if($r > 100) $r = 100; if($r < 0) $r = 0;
	return $r;
}


}	
endif;	

class ipzone{
			const TYPE_COUNTRY = 1;
			const TYPE_CITY = 2;
			const TYPE_LOCATION = 3;
			const TYPE_ISP = 4;
			const TYPE_FULL = 5;
			private $db;
			public function __construct(PDO $db) {
				$this->db = $db;
				$this->db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
			}				
			public function lookup($addr, $table_name = PREFIX."_zones") {
				if ($ret = $this->do_lookup($table_name, self::addr_type($addr), inet_pton($addr))) {
					if($ret){
					$ret->ip_start = inet_ntop($ret->ip_start);
					$ret->ip_end = inet_ntop($ret->ip_end);
					return $ret;
					} else return false;
				} else {
					return false;}}
			protected function do_lookup($table_name, $addr_type, $addr_start) {
 			try {
				$q = $this->db->prepare(functions::replace("SELECT `addr_type`, `ip_start`, `ip_end`, `country` from `%p_zones` where `addr_type` = ? and `ip_start` <= ? ORDER BY `ip_start` DESC limit 1",array("%p"=>PREFIX)));
				$q->execute(array($addr_type, $addr_start));
				return $q->fetchObject();
				} catch (Exception $e) {
					//$this->db->query(functions::replace("UPDATE `%p_settings` SET `n_zones` = '', `n_zones_perc` = '0' WHERE `n_id` = '0';",array("%p"=>PREFIX)))->fetchAll(PDO::FETCH_ASSOC); 
					return false; }	
			}			
			static private function addr_type($addr) {
				if (ip2long($addr) !== false) {
					return "ipv4";
				} else if (preg_match('/^[0-9a-fA-F:]+$/', $addr) && @inet_pton($addr)) {
					return "ipv6";
				}
				return false;
			}	
}
//mixed style D
?>