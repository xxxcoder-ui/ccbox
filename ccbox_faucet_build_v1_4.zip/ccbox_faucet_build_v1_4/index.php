<?
error_reporting(0);
$html           = null;
$__USER_DATA    = null;
$engine         = null;
$rc             = null;
if(file_exists($_SERVER["DOCUMENT_ROOT"]."/core/config.php")) require_once($_SERVER["DOCUMENT_ROOT"]."/core/config.php"); else exit("core/congig.php not found");
if(file_exists($_SERVER["DOCUMENT_ROOT"]."/core/functions.php")) require_once($_SERVER["DOCUMENT_ROOT"]."/core/functions.php"); else exit("core/functions.php not found");
if(file_exists($_SERVER["DOCUMENT_ROOT"]."/core/engine.php")) require_once($_SERVER["DOCUMENT_ROOT"]."/core/engine.php"); else exit("core/engine.php not found");
if($__SECTION_SETTINGS[end($current)]['engine']) { if(file_exists($_SERVER["DOCUMENT_ROOT"]."/core/faucet/".$__SECTION_SETTINGS[end($current)]['engine'])) require_once($_SERVER["DOCUMENT_ROOT"]."/core/faucet/".$__SECTION_SETTINGS[end($current)]['engine']); else exit($_SERVER["DOCUMENT_ROOT"]."/core/faucet/".$__SECTION_SETTINGS[end($current)]['engine']." not found"); } else {  header("HTTP/1.0 404 Not Found");$__SECTION_DATA[end($current)]['s_title'] = "404. Page not found!"; $__SECTION_SETTINGS[end($current)]['template'] = "404.tmp.html"; }
if(file_exists($_SERVER["DOCUMENT_ROOT"]."/templates/".TEMPLATE."/header.tmp.html")) $html.= file_get_contents($_SERVER["DOCUMENT_ROOT"]."/templates/".TEMPLATE."/header.tmp.html"); else exit("templates/".TEMPLATE."/header.tmp.html not found");
if($__SECTION_SETTINGS[end($current)]['template']) if(file_exists($_SERVER["DOCUMENT_ROOT"]."/templates/".TEMPLATE."/".$__SECTION_SETTINGS[end($current)]['template'])) 
$html.= file_get_contents($_SERVER["DOCUMENT_ROOT"]."/templates/".TEMPLATE."/".$__SECTION_SETTINGS[end($current)]['template']); else exit("templates/".TEMPLATE."/".$__SECTION_SETTINGS[end($current)]['template']." not found");
if(file_exists($_SERVER["DOCUMENT_ROOT"]."/templates/".TEMPLATE."/footer.tmp.html")) $html.= file_get_contents($_SERVER["DOCUMENT_ROOT"]."/templates/".TEMPLATE."/footer.tmp.html"); else exit("templates/".TEMPLATE."/footer.tmp.html not found");
if(!functions::auth()){  
if(isset($__SECTION_SETTINGS[end($current)]['nauth_redirect'])) {	
if($__SECTION_SETTINGS[end($current)]['nauth_redirect']=="main") header('Location: //'.$_SERVER['HTTP_HOST']); else  header('Location: //'.$_SERVER['HTTP_HOST'].'/'.$__SECTION_SETTINGS[end($current)]['nauth_redirect']); }}	
if($__FAUCET_DATA['n_aab']==1) $fa = '<script src="%path/assets/js/jquery.fadb.js"></script>';
if($__FAUCET_DATA['n_capt']==1) $rc = '<script src="https://www.google.com/recaptcha/api.js"></script>';
$menu = functions::build_tree($c,0,false,"nav navbar-nav pull-right",0,$__SECTION_SETTINGS,$__USER_DATA['u_status']);
$base = array("%title"=>$__SECTION_DATA[end($current)]['s_title'],"%description"=>$__SECTION_DATA[end($current)]['s_desc'],"%countdown_start"=>"","%menu"=>$menu,"%fadblock_detect"=>$fa,"%year"=>date("Y"),"%recaptapi"=>$rc,"%path"=>"/templates/".TEMPLATE,"%sitename"=>ucfirst($__FAUCET_DATA['n_sitename']));
if($engine) $builder = array_merge($base,$engine); else $builder = $base;
$html = functions::replace($html,$builder);
echo $html;
$dbh = null;
?>