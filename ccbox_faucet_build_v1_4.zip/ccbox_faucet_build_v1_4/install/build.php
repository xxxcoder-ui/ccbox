<?
session_start();
$_ERROR = false;
$_STEP  = false;
//////////
//
//
$functions = new functions();
$opt = array(
PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
);
try{ $dbh = new PDO(functions::replace("mysql:host=%h;dbname=%b;charset=UTF8",array("%h"=>DBHOST,"%b"=>DBNAME)), DBUSER, DBPASS, $opt);  }
catch (Exception $e) { 

echo "<br/><ol><li>Find the Create New Database section on your hosting admin panel, then indicate name of the future database and click on the Create Database button.</li><li>To create a MySQL User, find the section Add New MySQL User and choose the username you wish to assign to your database. Choose a secure password for MySQL User and type it into the corresponding fields. Specify all privileges for the user.</li><li>Add these parameters to /core/config.php (DBHOST: localhost, DBNAME: database name, DBUSER: MySQL user name, DBPASS: MySQL user password) save changes and reload this page.
</li></ol>"; exit();
}
//////////
//
//
if(!$_STEP){

$dbh->query(functions::replace("
									   
CREATE TABLE IF NOT EXISTS `%p_coins` (
  `c_coin` varchar(11) NOT NULL,
  `c_name` varchar(255) NOT NULL,
  `c_alias` varchar(255) NOT NULL,
  `c_timer` int(11) NOT NULL,
  `c_min_pay` bigint(20) UNSIGNED NOT NULL,
  `c_max_pay` bigint(20) UNSIGNED NOT NULL,
  `c_hp` int(11) UNSIGNED NOT NULL,
  `c_redirect` enum('0','1') NOT NULL,
  `c_redirect_url` varchar(255) NOT NULL,
  `c_redirect_backward_url` varchar(255) NOT NULL,
  `c_deposit` enum('0','1') NOT NULL,
  `c_withdraw` enum('0','1') NOT NULL,
  `c_min_withdrawal` bigint(20) UNSIGNED NOT NULL,
  `c_fee_withdrawal` bigint(20) UNSIGNED NOT NULL,
  `c_order` int(11) NOT NULL,
  `c_faucet` enum('0','1') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

ALTER TABLE `%p_coins`
  ADD UNIQUE KEY `c_coin` (`c_coin`),
  ADD KEY `c_faucet` (`c_faucet`),
  ADD KEY `c_alias` (`c_alias`);

CREATE TABLE IF NOT EXISTS `%p_sections` (
  `s_id` int(11) NOT NULL,
  `s_alias` varchar(100) NOT NULL,
  `s_name` varchar(100) NOT NULL,
  `s_title` varchar(100) NOT NULL,
  `s_desc` varchar(255) NOT NULL,
  `s_settings` text NOT NULL,
  `s_parent` int(11) NOT NULL,
  `s_order` int(10) NOT NULL,
  `s_status` enum('0','1','2') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

ALTER TABLE `%p_sections`
  ADD PRIMARY KEY (`s_id`),
  ADD KEY `s_alias` (`s_alias`);
  
ALTER TABLE `%p_sections`
  MODIFY `s_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;  

INSERT INTO `%p_sections` (`s_id`, `s_alias`, `s_name`, `s_title`, `s_desc`, `s_settings`, `s_parent`, `s_order`, `s_status`) VALUES
(1, '', 'Home', '%sitename - Multicoins Faucets based on CCBOX.IO', 'Earn multi crypto coins with faucets on %sitename', '{\"engine\":\"main.eng.php\",\"template\":\"main.tmp.html\"}', 0, 1, '1'),
(2, 'about', 'About', 'About', 'About ', '{\"engine\":\"about.eng.php\",\"template\":\"about.tmp.html\"}', 0, 2, '0'),
(3, 'faucets', 'Faucets', 'Faucets', 'Faucets', '{\"engine\":\"empty.eng.php\",\"template\":\"faucet.list.tmp.html\"}', 0, 3, '1'),
(4, 'stat', 'Statistics', 'Statistics', 'Statistics', '{\"engine\":\"empty.eng.php\",\"template\":\"stat.tmp.html\"}', 0, 4, '1'),
(10, 'contact', 'Contact', 'Contact', 'Contact', '{\"engine\":\"contact.eng.php\",\"template\":\"contact.tmp.html\"}', 0, 5, '0'),
(11, 'profile', '<i class=\"fa fa-user\"></i> Profile', 'Profile', 'Profile', '{\"engine\":\"profile.eng.php\",\"template\":\"profile.tmp.html\",\"button_class\":\"btn\"}', 0, 6, '1'),
(12, 'admin', '<i class=\"fa fa-cog\"></i> Admin', 'Admin', 'Admin', '{\"engine\":\"admin.eng.php\",\"template\":\"admin.tmp.html\",\"button_class\":\"btn\"}', 0, 7, '2');

CREATE TABLE IF NOT EXISTS `%p_settings` (
  `n_id` int(11) NOT NULL,
  `n_hash` varchar(255) NOT NULL,
  `n_okey` varchar(255) NOT NULL,
  `n_skey` varchar(255) NOT NULL,
  `n_sitename` varchar(255) NOT NULL,
  `n_daily` int(10) DEFAULT NULL,
  `n_daily_o` enum('0','1') NOT NULL,
  `n_hp` int(10) UNSIGNED DEFAULT NULL,
  `n_iphub` enum('0','1') NOT NULL,
  `n_iphub_key` varchar(255) NOT NULL,
  `n_aab` enum('0','1') NOT NULL,
  `n_capt` enum('0','1') NOT NULL,
  `n_capt_okey` varchar(255) NOT NULL,
  `n_capt_skey` varchar(255) NOT NULL,
  `n_zones` text NOT NULL,
  `n_zones_perc` int(10) NOT NULL,
  `n_adv_faucet` text NOT NULL,
  `n_connect` enum('0','1') NOT NULL,
  `n_status` enum('0','1') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

ALTER TABLE `%p_settings`
  ADD PRIMARY KEY (`n_id`);
  
ALTER TABLE `%p_settings`
  MODIFY `n_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;   

INSERT INTO `%p_settings` (`n_id`, `n_hash`, `n_okey`, `n_skey`, `n_sitename`, `n_daily`, `n_daily_o`, `n_hp`, `n_iphub`, `n_iphub_key`, `n_aab`, `n_capt`, `n_capt_okey`, `n_capt_skey`, `n_zones`, `n_zones_perc`, `n_adv_faucet`, `n_connect`, `n_status`)
VALUES (NULL, '', '', '', '', '0', '0', '1', '0', '', '1', '0', '', '', '', '0', '', '0', '1');

CREATE TABLE IF NOT EXISTS `%p_trs_history` (
  `th_id` bigint(20) NOT NULL,
  `th_user_id` bigint(20) NOT NULL,
  `th_user_name` varchar(255) NOT NULL,
  `th_type` enum('0','1') NOT NULL COMMENT '0 - reward 1- ref',
  `th_coin` varchar(10) NOT NULL,
  `th_amount` bigint(255) NOT NULL,
  `th_fee` mediumint(9) NOT NULL,
  `th_part_id` bigint(20) NOT NULL,
  `th_datetime` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


ALTER TABLE `%p_trs_history`
  ADD PRIMARY KEY (`th_id`),
  ADD KEY `th_user_id` (`th_user_id`);
  
ALTER TABLE `%p_trs_history`
  MODIFY `th_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;  

CREATE TABLE IF NOT EXISTS `%p_users` (
  `u_id` bigint(20) NOT NULL,
  `u_hash` varchar(255) NOT NULL,
  `u_ip` varchar(255) NOT NULL,
  `u_geo` varchar(10) NOT NULL,
  `u_session` bigint(11) NOT NULL,
  `u_name` varchar(255) NOT NULL,
  `u_email` varchar(255) NOT NULL,
  `u_password` varchar(255) NOT NULL,
  `u_reg_datetime` bigint(11) NOT NULL,
  `u_last_online` bigint(11) NOT NULL,
  `u_ref_id` bigint(11) NOT NULL,
  `u_settings` text NOT NULL,
  `u_status` enum('0','1','2') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

ALTER TABLE `%p_users`
  ADD PRIMARY KEY (`u_id`),
  ADD UNIQUE KEY `u_hash` (`u_hash`);

ALTER TABLE `%p_users`
  MODIFY `u_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;COMMIT;",array("%p"=>PREFIX))); 
}


$stmt = $dbh->query(functions::replace("SELECT * FROM `%p_settings` WHERE `n_id` = '1' LIMIT 1",array("%p"=>PREFIX)))->fetchAll(PDO::FETCH_ASSOC); 
foreach ($stmt as $row) {$__FAUCET_DATA = $row;}
if(!$__FAUCET_DATA['n_hash']||!$__FAUCET_DATA['n_okey']||!$__FAUCET_DATA['n_skey']) $_STEP = 1; else $_STEP = 2; 


if($_POST&&$_STEP == 1){
	
$_POST['n_okey'] = strip_tags(trim($_POST['n_okey']));
$_POST['n_skey'] = strip_tags(trim($_POST['n_skey']));
$_POST['n_hash'] = preg_replace("/CCBOX-/", "", $_POST['n_hash']);
$_POST['n_hash'] = strip_tags(trim($_POST['n_hash']));
if(strlen($_POST['n_okey'])<32) $_ERROR = "CCBOX: Wrong CCBOX KEYS";
if(strlen($_POST['n_skey'])<32) $_ERROR = "CCBOX: Wrong CCBOX KEYS";
//////////
//
//
if(!$_ERROR){	
$date = new DateTime();
$data = array(
'h' 	=> $_POST['n_hash'],
'r' 	=> $_POST['n_hash'],
'n' 	=> $date->getTimestamp(),
'k' 	=> functions::encrypt($_POST['n_okey'], $_POST['n_skey'], $date->getTimestamp())
);
$__out = json_decode(functions::ccbox("https://ccbox.io/api/user/",$data), true);
if($__out['code']!=200) 
{
$_ERROR = "CCBOX: User not found";		
}
else
{
$sql = functions::replace("UPDATE `%p_settings` SET `n_hash` = :h, `n_okey` = :ok, `n_skey` = :sk, `n_sitename` = :sn, `n_connect` = '1' WHERE `n_id` = '1'; 
						  INSERT INTO `%p_users` (`u_id`, `u_hash`, `u_ip`, `u_geo`, `u_session`, `u_name`, `u_email`, `u_password`, `u_reg_datetime`, `u_last_online`, `u_ref_id`, `u_settings`, `u_status`) VALUES (NULL, :h, :ip, '', UNIX_TIMESTAMP(), :un, :um, :up, UNIX_TIMESTAMP(), UNIX_TIMESTAMP(), '0', '', '2');",array("%p"=>PREFIX));														
$stmt =  $dbh->prepare($sql);
$stmt -> execute(array('h' => $_POST['n_hash'], 'ip' => functions::getip(), 'ok' => $_POST['n_okey'], 'sk' => $_POST['n_skey'], 'sn' => $_POST['sitename'], 'un' => $_POST['nickname'], 'um' => $_POST['email'], 'up' => md5(md5($_POST['password']))));
$d = $dbh->lastInsertId();
functions::fsetcookie($_POST['n_hash'],$d,date("Y/m/d H:i:s"),$_POST['email'],md5(md5($_POST['password']))); 
header("location: /install");
}
}} 
//////////
//
//
//////////
//
//
if($_STEP == 2){	
if($_SESSION['data']) {
$_ERROR = null;
}else{
$date = new DateTime();
$data = array(
'h' 	=> $__FAUCET_DATA['n_hash'],
'n' 	=> $date->getTimestamp(),
'k' 	=> functions::encrypt($__FAUCET_DATA['n_okey'], $__FAUCET_DATA['n_skey'], $date->getTimestamp())
);
$__out = json_decode(functions::ccbox("https://ccbox.io/api/coins/",$data), true);
if($__out['code']==200 && count($__out['data']>0)) $_SESSION['data'] = $__out['data']; else $_ERROR = "CCBOX: Error Connection to API. Try reinstalling the site. Contact administrator."; 
}
//////////
//
//
if($_STEP == 2 && !$_ERROR && $_SESSION['data']){
//section searching
if(FAUCET_SECTION) $faucet_section_alias = FAUCET_SECTION; else $faucet_section_alias = "faucets";
$faucet_section_id = $dbh->query(functions::replace("SELECT `s_id` FROM `%p_sections` WHERE `s_alias` = '%a'",array("%p"=>PREFIX,"%a"=>$faucet_section_alias)))->fetch(PDO::FETCH_ASSOC);
/////////////
$or = 1;
$__cs= functions::replace("INSERT INTO `%p_coins` (`c_coin`, `c_name`, `c_alias`, `c_timer`, `c_min_pay`, `c_max_pay`, `c_hp`, `c_redirect`, `c_redirect_url`, `c_redirect_backward_url`, `c_deposit`, `c_withdraw`, `c_min_withdrawal`, `c_fee_withdrawal`, `c_order`, `c_faucet`) VALUES ",array("%p"=>PREFIX));
$__ss= functions::replace("INSERT INTO `%p_sections` (`s_id`, `s_alias`, `s_name`, `s_title`, `s_desc`, `s_settings`, `s_parent`, `s_order`, `s_status`) VALUES ",array("%p"=>PREFIX));

foreach ($_SESSION['data'] as $v){
$__f[] = functions::replace("(NULL, '%c', '%n', '%t', '%d', '{\"engine\":\"faucet.page.eng.php\",\"template\":\"faucet.page.tmp.html\"}', '%a', '', '0')",array("%c"=>$v['symbol'],"%n"=>$_SESSION['data'][$v['symbol']]['name']." Faucet","%t"=>$_SESSION['data'][$v['symbol']]['name']." Faucet based on CCBOX.IO","%d"=>$_SESSION['data'][$v['symbol']]['name']." Faucet - earn free ".$_SESSION['data'][$v['symbol']]['name']." on ".$__FAUCET_DATA['n_sitename'],"%a"=>$faucet_section_id['s_id']));	
$__c[]= functions::replace("('%c', '%n', '%a', '30', '100', '0', '20', '0', '', '', '0', '1', '0', '0', '%or', '0')",array("%p"=>PREFIX,"%c"=>$v['symbol'],"%or"=>$or,"%n"=>$_SESSION['data'][$v['symbol']]['name'],"%a"=>$_SESSION['data'][$v['symbol']]['alias']));	
$or++;}
if($__c){
$sql = $__cs.implode(", ",$__c)."; ".$__ss.implode(", ",$__f).";";
$stmt =  $dbh->prepare($sql);
$stmt -> execute();
///////
session_destroy();
header("location: /admin");
}
} 
//////////
//
}
//
?>