<?php
//INSTALLATION
error_reporting(0);
if(file_exists($_SERVER["DOCUMENT_ROOT"]."/core/config.php")) require_once($_SERVER["DOCUMENT_ROOT"]."/core/config.php"); else exit("core/congig.php not found");
if(file_exists($_SERVER["DOCUMENT_ROOT"]."/core/functions.php")) require_once($_SERVER["DOCUMENT_ROOT"]."/core/functions.php"); else exit("core/functions.php not found");
if(file_exists($_SERVER["DOCUMENT_ROOT"]."/install/build.php")) require_once($_SERVER["DOCUMENT_ROOT"]."/install/build.php"); else exit("/install/build.php not found");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="description" content="">
<title></title>
<link rel="shortcut icon" href="/install/assets/images/gt_favicon.png">
<link rel="stylesheet" media="screen" href="http://fonts.googleapis.com/css?family=Open+Sans:300,400,700">
<link rel="stylesheet" href="/install/assets/css/bootstrap.min.css">
<link rel="stylesheet" href="/install/assets/css/font-awesome.min.css">
<link rel="stylesheet" href="/install/assets/css/bootstrap-theme.css" media="screen" >
<link rel="stylesheet" href="/install/assets/css/main.css">
<!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
<!--[if lt IE 9]>
	<script src="/install/assets/js/html5shiv.js"></script>
	<script src="/install/assets/js/respond.min.js"></script>
	<![endif]-->
</head>
<body class="home">
<div class="navbar navbar-inverse navbar-fixed-top headroom" >
    
          <div class="navbar-header"> <a class="navbar-brand" href="/"><i class="fa fa-cog fa-spin" ></i> Installation</a> </div>
    
</div>
<header id="head" class="secondary"></header>
<div class="container">
     <div class="row">
          <article class="col-lg-12 maincontent">
               <? if($_STEP==1) { ?>
               <form class="bordered-form" method="post" name="basic-settings">
                    <header class="page-header">
                         <h1 class="page-title">Admin Settings</h1>
                    </header>
                    <?  if($_ERROR) { ?>
                    <p class="won" ><span data-error id="bl"><i class="fa fa-info-circle"></i>
                         <?=$_ERROR?>
                         </span></p>
                    <? } else { ?>
                    <p class="won"><i class="fa fa-info-circle"></i> To get CCBOX keys, register on <a href="https://ccbox.io/signup">ccbox.io</a> as faucet owner, go to SETTINGS and activate API access.</p>
                    <? } ?>
                    <div class="row">
                         <div class="col-lg-12">
                              <label>CCBOX Key Hash</label>
                              <input name="n_hash" maxlength="50" class="form-control" type="text" placeholder="Set your CCBOX Key" autocomplete="off" value="<?=$_POST['n_hash']?>" required>
                         </div>
                    </div>
                    <br>
                    <div class="row">
                         <div class="col-lg-12">
                              <label>CCBOX Open Key</label>
                              <input name="n_okey" maxlength="50" class="form-control" type="text" placeholder="Set your CCBOX Open Key" autocomplete="off" value="<?=$_POST['n_okey']?>" required>
                         </div>
                    </div>
                    <br>
                    <div class="row">
                         <div class="col-lg-12">
                              <label>CCBOX Secret Key</label>
                              <input name="n_skey"  maxlength="50" class="form-control" type="text" placeholder="Set your CCBOX Secret Key" autocomplete="off" value="<?=$_POST['n_skey']?>" required>
                         </div>
                    </div>
                    <br>
                    <div class="row">
                         <div class="col-lg-4">
                              <label>Admin E-mail</label>
                              <input name="email" maxlength="50"  class="form-control" type="email" placeholder="Type your email" autocomplete="off" value="<?=$_POST['email']?>" required>
                         </div>
                    
                         <div class="col-lg-4">
                              <label>Admin Password</label>
                              <input name="password" maxlength="50"  class="form-control" type="password" placeholder="Set admin password" value="" required>
                         </div>
                    
                         <div class="col-lg-4">
                              <label>Nickname</label>
                              <input name="nickname" maxlength="50"  class="form-control" type="text" placeholder="Set admin nickname" autocomplete="off" value="<?=$_POST['nickname']?>" required>
                         </div>
                    </div>
                    <br>
                    <div class="row">
                         <div class="col-lg-12">
                              <label>Site Name</label>
                              <input name="sitename" maxlength="50"  class="form-control" type="text" placeholder="Set site name" autocomplete="off" value="<?=$_POST['sitename']?>" required>
                         </div>
                    </div>
                    <br/>
                    <div class="row">
                         <div class="col-sm-6">
                              <button type="submit" class="btn btn-action">NEXT STEP</button>
                         </div>
                    </div>
                    <br/>
               </form>
               <? } ?>
               <? if($_STEP==2) { ?>
               <form method="post" class="bordered-form" name="basic-settings-2">
                    <header class="page-header">
                         <h1 class="page-title">Faucet Settings</h1>
                    </header>
                    <?  if($_ERROR) { ?>
                    <p class="won" ><span data-error id="bl"><i class="fa fa-info-circle"></i>
                         <?=$_ERROR?>
                         </span></p>
                    <? } else { ?>
                    <p class="won"><i class="fa fa-info-circle"></i> Select the coins your faucet will offer and activate them.</p>
                    <? } ?>
                    <?=$coins?>
                    <div class="row">
                         <div class="col-sm-6">
                              <button type="submit" class="btn btn-action">NEXT STEP</button>
                         </div>
                    </div>
                    <br/>
               </form>
               <? } ?>
               <? if($_STEP==3) { ?>
               <form method="post" class="bordered-form" name="basic-settings-2">
                    <header class="page-header">
                         <h1 class="page-title">Basic Installation Complete</h1>
                    </header>
                    <?  if($_ERROR) { ?>
                    <p class="won" ><span data-error id="bl"><i class="fa fa-info-circle"></i>
                         <?=$_ERROR?>
                         </span></p>
                    <? } else { ?>
                    <p class="won"><i class="fa fa-info-circle"></i> Go to the main page and type your CCBOX KEY</p>
                    <? } ?>
                    <div class="row">
                         <div class="col-sm-6">
                              <a href="/" class="btn btn-action">Main Page</a>
                         </div>
                    </div>
                    <br/>
               </form>
               <? } ?>
          </article>
     </div>
</div>
<footer id="footer" class=""></footer>
</body>
</html>
<script src="/install/assets/js/jquery.min.js"></script>
<script src="/install/assets/js/jquery.bootstrap.min.js"></script>
<script src="/install/assets/js/jquery.headroom.tmp.min.js"></script>
<script src="/install/assets/js/jquery.headroom.min.js"></script>
<script src="/install/assets/js/jquery.data.tables.js"></script>
<script>
$(document).ready(function() {

$(".headroom").headroom({
"tolerance": 20,
"offset": 50,
"classes": {
"initial": "animated",
"pinned": "slideDown",
"unpinned": "slideUp"
}
});	

$('.redirect').bind('change', function () {
coin=$(this).data("coin");
$(this).toggleClass("off");
if($(this).val()==0) $('.' + coin + '-redirect-url').prop('disabled', true); else $('.' + coin + '-redirect-url').prop('disabled', false);
});

$('.active').bind('change', function () {
coin=$(this).data("coin");
$(this).toggleClass("off");
if($(this).val()==0) $('.' + coin + '-settings').prop('disabled', true); else { $('.' + coin + '-settings').prop('disabled', false);
if($('.' + coin + '-redirect').val()==0) { $('.' + coin + '-redirect-url').prop('disabled', true); } else { $('.' + coin + '-redirect-url').prop('disabled', false); } }
});
});
</script>
<? $dbh = null; ?>