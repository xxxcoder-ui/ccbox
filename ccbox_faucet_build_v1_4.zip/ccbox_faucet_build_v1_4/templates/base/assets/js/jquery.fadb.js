function adBlockNotDetected() {
$('#footer-message').hide();
}
function adBlockDetected() {
$('#footer-message').html('<i class="fa fa-info-circle"></i> Please turn off adblocker!');	
$('#footer-message').show();
$('#claim').remove();
$('#message_block').remove();
$('.g-recaptcha').remove();
}
if(typeof fuckAdBlock !== 'undefined' || typeof FuckAdBlock !== 'undefined') {adBlockDetected();} else {
var importFAB = document.createElement('script');
importFAB.onload = function() {
fuckAdBlock.onDetected(adBlockDetected)
fuckAdBlock.onNotDetected(adBlockNotDetected);};
importFAB.onerror = function() {adBlockDetected();};
importFAB.crossOrigin = 'anonymous';
importFAB.src = 'https://cdnjs.cloudflare.com/ajax/libs/fuckadblock/3.2.1/fuckadblock.js';
document.head.appendChild(importFAB);}