$(document).ready(function() {

$(".headroom").headroom({
"tolerance": 20,
"offset": 50,
"classes": {
"initial": "animated",
"pinned": "slideDown",
"unpinned": "slideUp"
}
});	

$("#login").click(function () {		
$(this).addClass("disabled");
$(this).html('<i class="fa fa-cog fa-spin"></i> Processing...');	
setTimeout(function() {	
$("#login_form").submit();
}, 1000);
});

$("#logout").click(function () {							
$.ajax({
type: "POST",	   
url: "/core/faucet/logout.inc.php",
dataType: 'json',
success: function(response) {
window.location.href = "/";
}});});

$("#registration").click(function () {
$("#message").empty();							
key = $("#key").val(); 
if(key){
$(this).html('<i class="fa fa-cog fa-spin"></i> PROCESSING...');		
$(this).addClass("disabled");
setTimeout(function() {
$.ajax({
type: "POST",
url: "/core/faucet/reg.user.inc.php",
data: {"key": key},
dataType: 'json',
success: function(response) {
$("#key").val("");	
if(response['error'])   { 
$("#message").html("<span data-error>" + response['error'] + "</span>");  $("#registration").html('SIGN UP');	
$("#registration").removeClass("disabled"); setTimeout(function() {$("#message").empty();}, 5000);}
if(response['success']) { $("#message").html("<span data-success>" + response['success'] + "</span>"); setTimeout(function() {window.location.href = response['redirect']}, 2500);  }
}
});	}, 1000);
}
});

$("#save").click(function () {						   
$("#message").empty();							
name = $("#name").val(); 
if(name){
$("#save").html('<i class="fa fa-cog fa-spin"></i> PROCESSING...');		
$("#save").addClass("disabled");
setTimeout(function() {
$.ajax({
type: "POST",
url: "/core/faucet/profile.save.changes.php",
data: {"name": name},
dataType: 'json',
success: function(response) {
if(response['error'])   { $("#message").html("<span data-error>" + response['error'] + "</span>"); }
if(response['success']) { $("#message").html("<span data-success>" + response['success'] + "</span>");  }
$("#save").html('SAVE CHANGES');	
$("#save").removeClass("disabled");
setTimeout(function() {$("#message").empty();}, 5000);
}
});	 }, 1000);
}
}); 

$('.redirect').bind('change', function () {
coin=$(this).data("coin");
$(this).toggleClass("off");
if($(this).val()==0) $('.' + coin + '-redirect-url').prop('disabled', true); else $('.' + coin + '-redirect-url').prop('disabled', false);
});

$('.captcha select').bind('change', function () {
if($(this).val()==0) $('.recaptcha').addClass('hide'); else $('.recaptcha').removeClass('hide');
});

$('.active').bind('change', function () {
coin=$(this).data("coin");
$(this).toggleClass("off");
if($(this).val()==0) $('.' + coin + '-settings').prop('disabled', true); else { $('.' + coin + '-settings').prop('disabled', false);
if($('.' + coin + '-redirect').val()==0) { $('.' + coin + '-redirect-url').prop('disabled', true); } else { $('.' + coin + '-redirect-url').prop('disabled', false); } }
});

$('.chpp').bind('change click keyup',function(){
if($(this).val()>0) $(this).removeClass("off"); else $(this).addClass("off");
});

$('.ctmr').bind('change click keyup',function(){
$('.ctmr').val($(this).val()); 
});

$('.daily select').on('change',function(){
$('.daily_value input').removeClass("on off");
if($(this).val()==1) { $('.daily_value input').addClass("on"); $('.daily_value input').prop('required',true);  $('.daily_value input').prop('disabled',false); $('.daily_sp select').prop('disabled',false); 
if($('.daily_sp select').val()==0) { $('.daily_sp select').addClass("off"); }}

if($(this).val()==0) { $('.daily_value input').addClass("off"); $('.daily_value input').prop('required',false); $('.daily_value input').val(0); $('.daily_value input').prop('disabled',true); $('.daily_sp select').prop('disabled',true); $('.daily_sp select').removeClass("on"); $('.daily_sp select').val(0);} 
});

$('.ipcheck select').on('change',function(){
$('.ipcheck_key input').removeClass("on off");
if($(this).val()==1) { $('.ipcheck_key input').addClass("on"); $('.ipcheck_key input').prop('required',true); }
if($(this).val()==0) { $('.ipcheck_key input').addClass("off"); $('.ipcheck_key input').prop('required',false); $('.ipcheck_key input').val(""); } 
});

$('.select').on('change',function(){
$(this).removeClass("on off");
$(this).addClass($(this).find('option:selected').data('class'));
});

$("#admin-save").click(function () {
s = $('#settings').serializeArray();
p = $("#password").val();
if(s && p){
$("#admin-save").html('<i class="fa fa-cog fa-spin"></i> PROCESSING...');		
$("#admin-save").addClass("disabled");
setTimeout(function() {
$.ajax({
type: "POST",
url: "/core/faucet/admin.save.changes.php",
data: $.param(s),
dataType: 'json',
success: function(response) {
if(response['error'])   	{ $("#message").html("<span data-error>" + response['error'] + "</span>"); $('#modal').modal('show'); }
if(response['success']) 	{ $("#message").html("<span data-success>" + response['success'] + "</span>"); $('#modal').modal('show'); }
if(response['disabled']) 	{ $("#faucet-settings-a").empty();}
$("#password").val("");
$("#admin-save").html('SAVE CHANGES');	
$("#admin-save").removeClass("disabled");
}
});	 }, 1000);
}
$('#modal').on('hidden.bs.modal', function (e) {
window.location = "/admin";
})
});

$("#history_table").DataTable( {
"order": [[ 0, "desc" ]],
"pageLength": 20,
"processing": false,
"searching": true,
"serverSide": true,
"ajax": "/core/faucet/stat.eng.php",
"language": { 		
}
});	

$("#faucet_table").DataTable( {
"order": [[ 0, "desc" ]],
"pageLength": 5,
"processing": false,
"searching": true,
"serverSide": true,
"ajax": "/core/faucet/faucet.list.eng.php",
"language": { 		
}
});	

});